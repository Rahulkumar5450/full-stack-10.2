Frontend: Vite + React
- Start with: npm install
- Run: npm run start
- Edit API base via VITE_API_BASE env variable
