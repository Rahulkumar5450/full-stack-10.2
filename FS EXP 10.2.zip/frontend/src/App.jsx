import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Posts from './components/Posts';
import PostView from './components/PostView';

// configure base
const API = process.env.VITE_API_BASE || 'http://localhost:5000/api';

export default function App() {
  const [posts, setPosts] = useState([]);
  const [current, setCurrent] = useState(null);

  useEffect(() => {
    axios.get(API + '/posts').then(r => setPosts(r.data)).catch(console.error);
  }, []);

  return (
    <div style={{ padding:20, fontFamily:'Arial' }}>
      <h1>Blog Capstone</h1>
      <div style={{ display:'flex', gap:20 }}>
        <div style={{ width: '40%' }}>
          <Posts posts={posts} onOpen={(p)=>setCurrent(p)} refresh={() => axios.get(API + '/posts').then(r=>setPosts(r.data))} />
        </div>
        <div style={{ flex:1 }}>
          {current ? <PostView post={current} /> : <div>Select a post to view comments</div>}
        </div>
      </div>
    </div>
  );
}
