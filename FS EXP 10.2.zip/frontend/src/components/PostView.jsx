import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';
const API = (import.meta.env.VITE_API_BASE) || 'http://localhost:5000/api';

export default function PostView({ post }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [socket, setSocket] = useState(null);

  useEffect(()=> {
    const s = io((import.meta.env.VITE_SOCKET_URL) || 'http://localhost:5000');
    setSocket(s);
    s.emit('joinPost', post._id);
    s.on('commentAdded', (c) => {
      if (c.post === post._id || c.post === post._id) setComments(prev => [...prev, c]);
    });
    return ()=> { s.emit('leavePost', post._id); s.disconnect(); };
  }, [post._id]);

  useEffect(()=> {
    axios.get(API + '/comments/' + post._id).then(r=>setComments(r.data)).catch(console.error);
  }, [post._id]);

  const add = async () => {
    // for demo we use a guest token stored in localStorage (in real app use login)
    const token = localStorage.getItem('token');
    try {
      const resp = await axios.post(API + '/comments', { postId: post._id, text }, { headers: { Authorization: token ? 'Bearer ' + token : '' }});
      setText('');
      // emit to socket
      socket.emit('newComment', { postId: post._id, comment: resp.data });
      setComments(prev=>[...prev, resp.data]);
    } catch (err) {
      alert('You must be logged in to comment (or create a token in localStorage).');
    }
  };

  return (
    <div>
      <h2>{post.title}</h2>
      <div style={{ marginBottom:20 }}>{post.content}</div>
      <hr />
      <h3>Comments</h3>
      {comments.map(c=>(
        <div key={c._id} style={{ padding:8, borderBottom:'1px solid #eee' }}>
          <strong>{c.author?.name || 'Unknown'}</strong>
          <div>{c.text}</div>
        </div>
      ))}
      <div style={{ marginTop:10 }}>
        <textarea value={text} onChange={e=>setText(e.target.value)} rows={3} style={{ width:'100%' }} />
        <button onClick={add} style={{ marginTop:8 }}>Add comment</button>
      </div>
    </div>
  );
}
