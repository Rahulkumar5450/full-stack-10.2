import React from 'react';
export default function Posts({ posts, onOpen }) {
  return (
    <div>
      <h2>Posts</h2>
      {posts.map(p => (
        <div key={p._id} style={{ border:'1px solid #ddd', padding:10, marginBottom:8, cursor:'pointer' }} onClick={()=>onOpen(p)}>
          <strong>{p.title}</strong>
          <div style={{ fontSize:12 }}>{p.author?.name} • {new Date(p.createdAt).toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}
