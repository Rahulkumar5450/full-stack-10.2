Blog Capstone Project
=====================

What is included
- backend/: Node.js + Express + Mongoose + JWT + Socket.IO
- frontend/: Vite + React (simple client showing posts and real-time comments)

Quick start (local MongoDB)
1. Backend:
   - cd backend
   - cp .env.example .env  (edit MONGO_URI and JWT_SECRET if needed)
   - npm install
   - npm run dev
2. Frontend:
   - cd frontend
   - npm install
   - npm run start
   - Open http://localhost:5173

Notes
- Real-time comments use Socket.IO. When you post a comment via the API the client emits 'newComment' to update other viewers.
- For demonstration you can register via POST /api/auth/register and store the returned token in localStorage as 'token' to enable commenting.
