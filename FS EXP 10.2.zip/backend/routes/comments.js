const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Comment = require('../models/Comment');

// Add comment
router.post('/', auth, async (req, res) => {
  const { postId, text } = req.body;
  try {
    const comment = new Comment({ post: postId, author: req.user.id, text });
    await comment.save();
    await comment.populate('author', 'name');
    res.json(comment);
  } catch (err) { console.error(err); res.status(500).send('Server error'); }
});

// Get comments for a post
router.get('/:postId', async (req, res) => {
  const comments = await Comment.find({ post: req.params.postId }).populate('author', 'name').sort({ createdAt: 1 });
  res.json(comments);
});

module.exports = router;
