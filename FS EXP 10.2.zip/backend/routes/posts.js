const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Post = require('../models/Post');

// Create post
router.post('/', auth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const post = new Post({ title, content, author: req.user.id });
    await post.save();
    res.json(post);
  } catch (err) { console.error(err); res.status(500).send('Server error'); }
});

// Get all posts (with author)
router.get('/', async (req, res) => {
  const posts = await Post.find().populate('author', 'name email').sort({ createdAt: -1 });
  res.json(posts);
});

// Get single post
router.get('/:id', async (req, res) => {
  const post = await Post.findById(req.params.id).populate('author', 'name email');
  if (!post) return res.status(404).json({ msg: 'Not found' });
  res.json(post);
});

// Update post
router.put('/:id', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ msg: 'Not found' });
  if (post.author.toString() !== req.user.id) return res.status(403).json({ msg: 'Not allowed' });
  post.title = req.body.title || post.title;
  post.content = req.body.content || post.content;
  await post.save();
  res.json(post);
});

// Delete post
router.delete('/:id', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ msg: 'Not found' });
  if (post.author.toString() !== req.user.id) return res.status(403).json({ msg: 'Not allowed' });
  await post.remove();
  res.json({ msg: 'Deleted' });
});

module.exports = router;
