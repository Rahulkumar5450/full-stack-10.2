require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const { Server } = require('socket.io');
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');
const commentRoutes = require('./routes/comments');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/comments', commentRoutes);

// Socket.IO for real-time comments
io.on('connection', (socket) => {
  console.log('Socket connected', socket.id);
  socket.on('joinPost', (postId) => {
    socket.join(postId);
  });
  socket.on('leavePost', (postId) => {
    socket.leave(postId);
  });
  socket.on('newComment', (data) => {
    // broadcast to the post room
    io.to(data.postId).emit('commentAdded', data.comment);
  });
});

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/blogcapstone';

mongoose.connect(MONGO).then(()=> {
  console.log('Mongo connected');
  server.listen(PORT, ()=> console.log('Server listening on', PORT));
}).catch(err => {
  console.error('MongoDB connection error:', err.message);
});

